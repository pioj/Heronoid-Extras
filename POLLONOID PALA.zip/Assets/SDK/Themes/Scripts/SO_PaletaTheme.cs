﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace mierdergames
{

[System.Serializable]
public struct PaletteTile
{
  [SerializeField] public GameObject _prefabTile;
  [SerializeField] public Color32 _colorTile;
}

[CreateAssetMenu(fileName = "Theme_xxx", menuName = "Heronoid/Themes/Create theme Palette...")]
public class SO_PaletaTheme : ScriptableObject
{
  [SerializeField] public List<PaletteTile> theme = new List<PaletteTile>();


  //devuelvo la lista de colores disponibles
  public Color32[] GetColors()
  {
    var col = new Color32[theme.Count];

    for (int i = 0; i < theme.Count; i++)
    {
      col[i] = theme[i]._colorTile;
    }

    return col;
  }

}


}
