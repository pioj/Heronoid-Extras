
//TEMPORAL FIX: Please, include the UnityEngine; line to this code by yourself, in case it's not there...


using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEditor;
using TMPro;

public class Canvas_Pala : MonoBehaviour
{
	[Header("UI Elements")]
	public Button btn_palaLeft;
	public Button btn_palaCent;
	public Button btn_palaRight;

	public Button btn_palaRand;
	public Button btn_shop;

}

