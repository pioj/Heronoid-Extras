
//TEMPORAL FIX: Please, include the UnityEngine; line to this code by yourself, in case it's not there...


using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEditor;
using TMPro;
using UnityEngine;

public class Canvas_LevelClear : MonoBehaviour
{
	[Header("UI Elements")]
	public Button btn_shop;
	public TMP_Text text_levelname;
}

