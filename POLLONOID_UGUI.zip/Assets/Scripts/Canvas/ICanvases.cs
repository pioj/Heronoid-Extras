﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace mierdergames
{
    public interface ICanvas_ItemSelection
    {
        void goPrev();
        void goNext();
        //event Action<T> itemSelected;
        //event Action<T> itemUnlocked;
        void Unlock();
    }

    public interface ICanvas_Shop
    {
        void itemBuy();
        void ExitShop();
    }

    public interface ICanvas_Stats
    {
        void goShop();
        void Refresh();
    }

    public interface ICanvas_Backbutton
    {
        void goBack();
        void goNext();
    }
}


