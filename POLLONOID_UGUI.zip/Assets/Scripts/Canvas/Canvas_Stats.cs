
//TEMPORAL FIX: Please, include the UnityEngine; line to this code by yourself, in case it's not there...


using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEditor;
using TMPro;

public class Canvas_Stats: MonoBehaviour
{
	[Header("UI Elements")]
	public Button btn_coins;
	public Button btn_lives;
	public Button btn_keys;

	[Space(20)]
	public TMP_Text text_coins;
	public TMP_Text text_lives;
	public TMP_Text text_keys;
}

