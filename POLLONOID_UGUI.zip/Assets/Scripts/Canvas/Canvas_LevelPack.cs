
//TEMPORAL FIX: Please, include the UnityEngine; line to this code by yourself, in case it's not there...


using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEditor;
using TMPro;

public class Canvas_LevelPack: MonoBehaviour
{
	[Header("UI Elements")]
	public TMP_Text text_Packname;
	public Button btn_enterPack;
	public Button btn_nextPack;
	public Button btn_prevPack;
}

