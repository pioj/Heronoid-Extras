
//TEMPORAL FIX: Please, include the UnityEngine; line to this code by yourself, in case it's not there...


using System.Collections;
using System.Collections.Generic;
using mierdergames;
using UnityEngine.UI;
using UnityEditor;
using UnityEngine;
using TMPro;

public class Canvas_BackButton : MonoBehaviour, ICanvas_Backbutton
{
	[Header("UI Elements")]
	public Button btn_Back;
	public Button btn_Restart;
	public Button btn_Next;

	public void goBack()
	{
		throw new System.NotImplementedException();
	}

	public void goNext()
	{
		throw new System.NotImplementedException();
	}
}

