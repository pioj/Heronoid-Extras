﻿//TEMPORAL FIX: Please, include the UnityEngine; line to this code by yourself, in case it's not there...


using System.Collections;
using System.Collections.Generic;
using mierdergames;
using UnityEngine.UI;
using UnityEditor;
using UnityEngine;
using TMPro;

public class Canvas_AdBanner : MonoBehaviour
{
	[Header("UI Elements")]
	public Button btn_AdBanner;
}