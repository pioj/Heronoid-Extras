
//TEMPORAL FIX: Please, include the UnityEngine; line to this code by yourself, in case it's not there...


using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEditor;
using TMPro;

public class Canvas_Pala2 : MonoBehaviour
{
	[Header("UI Elements")]
	public Button btn_LeftPrev;
	public Button btn_LeftCurr;
	public Button btn_LeftNext;
	[Space(20)]
	public Button btn_CentPrev;
	public Button btn_CentCurr;
	public Button btn_CentNext;
	[Space(20)]
	public Button btn_RightPrev;
	public Button btn_RightCurr;
	public Button btn_RightNext;
	[Space(20)]
	public Button btn_palaRand;
	public Button btn_shop;

}

