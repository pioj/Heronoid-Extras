
//TEMPORAL FIX: Please, include the UnityEngine; line to this code by yourself, in case it's not there...


using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEditor;
using TMPro;

public class Canvas_Skills : MonoBehaviour
{
	[Header("UI Elements")]
	public Button btn_Skills;
}

