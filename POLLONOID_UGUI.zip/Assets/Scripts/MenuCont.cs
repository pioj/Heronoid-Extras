﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro.EditorUtilities;
using UnityEngine;

public class MenuCont : MonoBehaviour
{
    //eventos
    public event Action ScreensReady; 
    
    //canvas de FADE, para transiciones
    [Header("FADE"), SerializeField] private CanvasGroup FadeScreen;
    
    //canvas
    [Header("Pantallas"), SerializeField] private List<CanvasGroup> pantallas;
    private int lastScreen;
    private int currentScreen;
    
    //consts de las pantallas
    private const int C_LOGO = 1;
    private const int C_LOGIN = 2;
    private const int C_BANNER = 4;
    private const int C_STATS = 8;
    private const int C_SKILLS = 16;
    private const int C_LEVELPACK = 32;
    private const int C_BACKBUTTON = 64;
    private const int C_LEVELSELECTION = 128;
    private const int C_PALA = 256;
    
    //combos de pantallas
    private int Screen_Title = C_LOGO | C_LOGIN | C_BANNER;
    private int Screen_LevelPack = C_STATS | C_LEVELPACK | C_BACKBUTTON | C_BANNER;
    private int Screen_LevelSelection = C_STATS | C_SKILLS | C_LEVELSELECTION | C_PALA | C_BACKBUTTON | C_BANNER;
    private int Screen_LevelClear = C_STATS | C_SKILLS | C_BACKBUTTON | C_BANNER;


    void Start()
    {
        Init();
    }

    public void Init()
    {   
        EnableScreen(FadeScreen);
        
        foreach (var pant in pantallas)
        {
            DisableScreen(pant);
        }
        ScreensReady?.Invoke();
    }
    

    public void PutScreen(int idx)
    {
        EnableScreen(FadeScreen);
        
        /*
        if ((idx & C_LOGO) == C_LOGO) EnableScreen(pantallas[0]);
        if ((idx & C_LOGIN) == C_LOGIN) EnableScreen(pantallas[1]);
        if ((idx & C_BANNER) == C_BANNER) EnableScreen(pantallas[2]);
        if ((idx & C_STATS) == C_STATS) EnableScreen(pantallas[3]);
        if ((idx & C_SKILLS) == C_SKILLS) EnableScreen(pantallas[4]);
        if ((idx & C_LEVELPACK) == C_LEVELPACK) EnableScreen(pantallas[5]);
        if ((idx & C_BACKBUTTON) == C_BACKBUTTON) EnableScreen(pantallas[6]);
        if ((idx & C_LEVELSELECTION) == C_LEVELSELECTION) EnableScreen(pantallas[7]);
        if ((idx & C_PALA) == C_PALA) EnableScreen(pantallas[8]);
        */

        var numpants = pantallas.Count;
        
        for (int i = 0; i <= numpants; ++i)
        {
            if ((idx & (1<<i)) !=0 ) EnableScreen(pantallas[i]);
        }
        
        DisableScreen(FadeScreen);
    }

    private void DisableScreen(CanvasGroup pant)
    {
        pant.alpha = 0f;
        pant.interactable = false;
        var pc = pant.GetComponent<Canvas>();
        pc.enabled = false;
    }

    private void EnableScreen(CanvasGroup pant)
    {
        pant.alpha = 1f;
        pant.interactable = true;
        var pc = pant.GetComponent<Canvas>();
        pc.enabled = true;
    }

    private void ToggleScreen(CanvasGroup pant)
    {
        pant.alpha = Mathf.Clamp01(1f - pant.alpha);
        pant.interactable = !pant.interactable;
        var pc = pant.GetComponent<Canvas>();
        pc.enabled = !pc.enabled;
    }
}
