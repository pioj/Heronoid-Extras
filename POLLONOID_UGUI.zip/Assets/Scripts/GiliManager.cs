﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GiliManager : MonoBehaviour
{
    private MenuCont _menuComp;
    
    void Awake()
    {
        _menuComp = FindObjectOfType<MenuCont>();
    }

    // Start is called before the first frame update
    void Start()
    {
        _menuComp.ScreensReady += LanzaMenus;
    }

    private void OnDestroy()
    {
        _menuComp.ScreensReady += LanzaMenus;
    }

    private void LanzaMenus()
    {
        print("menus listos");
        //_menuComp.PutScreen(15);
    }
    
}
