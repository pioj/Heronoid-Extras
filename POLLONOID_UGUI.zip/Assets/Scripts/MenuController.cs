﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuController : MonoBehaviour
{
    //eventos
    public event Action<CanvasGroup, CanvasGroup> ChangedTo;

    //comunes
    [Header("Botones Comunes"), SerializeField] public Button btn_coins;
    public Button btn_lives;
    public Button btn_keys;
    public Button btn_prev;
    public Button btn_next;
    
    [Header("Textos Comunes"), SerializeField] public TMP_Text text_coins;
    public TMP_Text text_lives;
    public TMP_Text text_keys;
    
    //canvas
    [Header("Pantallas"), SerializeField] private List<CanvasGroup> pantallas;
    private CanvasGroup lastScreen;
    private CanvasGroup currentScreen;
    
    //consts de las pantallas
    private const int C_LOGO = 0;
    private const int C_LOGIN = 1;
    private const int C_BANNER = 2;
    private const int C_STATS = 4;
    private const int C_SKILLS = 8;
    private const int C_LEVELPACK = 16;
    private const int C_BACKBUTTON = 32;
    private const int C_LEVELSELECTION = 64;
    private const int C_PALA = 128;
    
    //combos de pantallas
    private int Screen_Title = C_LOGO | C_LOGIN | C_BANNER;
    private int Screen_LevelPack = C_STATS | C_LEVELPACK | C_BACKBUTTON | C_BANNER;
    private int Screen_LevelSelection = C_STATS | C_SKILLS | C_LEVELSELECTION | C_PALA | C_BACKBUTTON | C_BANNER;
    private int Screen_LevelClear = C_STATS | C_SKILLS | C_BACKBUTTON | C_BANNER;
    
    /// <summary>
    /// Desactiva todas las pantallas menos la 1a de Login, y suscribe al evento de cambio de pantalla.
    /// </summary>
    public void Init()
    {
        if (pantallas.Equals(null) || pantallas.Count < 1) return;

        foreach (var pant in pantallas)
        {
          Exit(pant);  
        }
        
        //le damos funcionalidad a los botones comunes
        SetupComunes();
        
        //Establezco la primera, la del Login
        Enter(pantallas[0]);
        //
    }

    private IEnumerator Exit(CanvasGroup screen)
    {
        screen.interactable = false;
        screen.alpha = 0f;
        screen.GetComponent<Canvas>().enabled = false;
        lastScreen = screen;
        //
        btn_prev.onClick.RemoveAllListeners();
        btn_next.onClick.RemoveAllListeners();
        //
        yield return new WaitForSeconds(0.5f);
    }

    private IEnumerator Enter(CanvasGroup screen)
    {
        screen.interactable = true;
        screen.alpha = 1f;
        screen.GetComponent<Canvas>().enabled = true;
        currentScreen = screen;
        //
        //
        yield return new WaitForSeconds(0.5f);
    }

    private IEnumerator ChangeFromTo(CanvasGroup from, CanvasGroup to)
    {
        yield return StartCoroutine(Exit(from));
        yield return StartCoroutine(Enter(to));
        ChangedTo?.Invoke(from,to);
    }

    private void SetupComunes()
    {
        //btn_coins.onClick.AddListener(tienda);
        //btn_lives.onClick.AddListener(tienda);
        //btn_keys.onClick.AddListener(tienda);
    }

    
    //Funciones de textos...
    private void RefreshStats()
    {
        RefreshCoins();
        RefreshLives();
        RefreshKeys();
    }

    private void RefreshCoins() {}
    private void RefreshLives() {}
    private void RefreshKeys() {}

}
