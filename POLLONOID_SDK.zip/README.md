Heronoid SDK is inside the Assets\folder.

It's a custom set of tools made with ScriptableObjects to Create and Import/Export several data from the game.