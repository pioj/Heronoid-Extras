﻿using System;
using System.Collections;
using System.Collections.Generic;
using mierdergames;
using UnityEngine;

public class LoadLevel : MonoBehaviour
{
    public GameObject prefabBrick;
    public Transform rootLevel;
    private BoxCollider2D LevelLimits;
    private Vector2 minLeft;
    private Vector2 bricksize;
    
    
    private int levelwidth = 6;
    private int levelheight = 4;
    private Vector2 brickmargin = new Vector2(0.1f,0.1f); //este margen queda chulo
    private int[] leveldata;

    [Space(20)] public SO_Level mylevel;

    void Awake()
    {
        LevelLimits = rootLevel.GetComponent<BoxCollider2D>();
    }

    void Start()
    {
        leveldata = mylevel.level._leveldata;
        
        bricksize = new Vector2(prefabBrick.transform.localScale.x, prefabBrick.transform.localScale.y);
        minLeft = new Vector2(LevelLimits.bounds.min.x, LevelLimits.bounds.min.y);
        
        //el orden es left->right y bottom->up
        for (int y = 0; y < (leveldata.Length/levelwidth); y++) //divido entre columnas y filas
        {
            for (int x = 0; x < (leveldata.Length/levelheight); x++)
            {
               var numbrick = (y*levelwidth)+x;
               if (leveldata[numbrick] != 0)
               {
                    var clon = Instantiate(prefabBrick);
                    clon.transform.name = "Brick_" + leveldata[numbrick].ToString();

                    var newpos = new Vector2(minLeft.x + bricksize.x / 2 + (bricksize.x * x) + (brickmargin.x * x),
                        minLeft.y + bricksize.y / 2 + (bricksize.y * y) + (brickmargin.y * y));
                    clon.transform.localPosition = newpos;

                    clon.transform.SetParent(rootLevel);
               }
            }
        }
    }

    
}
