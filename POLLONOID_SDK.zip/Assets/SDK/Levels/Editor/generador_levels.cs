﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Runtime.InteropServices.WindowsRuntime;
using mierdergames;
using UnityEngine;
using UnityEditor;


namespace mierdergames.sdk
{
    public class generador_levels : MonoBehaviour
    {
        //convierte un nivel a fichero binario, lo guarda en una ruta.
        [MenuItem("MierderGames/Heronoid/SDK/Levels/Generate Binary Level...")]
        private static void GenerateBinaryLevel()
        {
            GenSimpleLevel();
        }

        //Genera un nivel simple de prueba en memoria
        private static void GenSimpleLevel()
        {
            var simple = new BaseLevel {levelname = "test"};
            //simple data de mierder...
            simple.SetLeveldata(new int[] {1, 0, 0, 1, 1, 0, 1});

            BinaryFormatter bf = new BinaryFormatter();

            var filepath = EditorUtility.SaveFilePanelInProject("Save binary level", "test.leveldata", "leveldata",
                "Save binary level as...");

            if (filepath.Length == 0) return;

            FileStream file = File.Open(filepath, FileMode.OpenOrCreate);
            bf.Serialize(file, simple);
            file.Close();
        }

        //Convierte un fichero binario en un nivel
        [MenuItem("MierderGames/Heronoid/SDK/Levels/Load Binary Level...")]
        private static void LoadExternalBinaryLevel()
        {
            LoadBinaryLevel();
        }

        //interno que carga un fichero binario de level y lo deserializa a su clase
        private static void LoadBinaryLevel()
        {
            BinaryFormatter bf = new BinaryFormatter();

            var filepath = EditorUtility.OpenFilePanelWithFilters("Load binary level", Application.dataPath,
                new string[] {"leveldata", "leveldata"});

            if (filepath.Length == 0) return;

            var file = File.Open(filepath, FileMode.Open);
            file.Seek(0, SeekOrigin.Begin);

            var simple = (BaseLevel) bf.Deserialize(file);
            file.Close();

            if (simple == null) return;

            var output = JsonUtility.ToJson(simple, true);
            if (output == String.Empty) return;
            Debug.Log(output);
        }


        //convierte de textura a nivel
        [MenuItem("MierderGames/Heronoid/SDK/Levels/Load Level from Image...")]
        private static void LoadExternalImageLevel()
        {
            LoadTextureLevel();
        }

        //interno que carga un nivel guardado como textura-imagen y lo deserializa a su clase
        private static void LoadTextureLevel()
        {
            var filepath = EditorUtility.OpenFilePanelWithFilters("Load Texture", Application.dataPath,
                new string[] {"png", "png", "jpeg", "jpeg", "jpg", "jpg"});

            if (filepath.Length == 0) return;

            Texture2D texture = null;
            byte[] fileData = File.ReadAllBytes(filepath);
            texture = new Texture2D(2, 2);
            texture.LoadImage(fileData);
            texture.filterMode = FilterMode.Point;
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.Apply();

            int LevelWidth = texture.width;
            int LevelHeight = texture.height;
            Color[] myPixels = texture.GetPixels(0, 0, LevelWidth, LevelHeight);
            Color32[] AllPixels = new Color32[myPixels.Length];

            for (int i = 0; i < myPixels.Length; i++)
            {
                AllPixels[i].r = (byte) (myPixels[i].r * 255);
                AllPixels[i].g = (byte) (myPixels[i].g * 255);
                AllPixels[i].b = (byte) (myPixels[i].b * 255);
                AllPixels[i].a = (byte) (myPixels[i].a * 255);
            }

            var simple = new BaseLevel {levelname = "ImageLevel"};
            simple.SetLeveldata(new int[AllPixels.Length]);

            for (int m = 0; m < AllPixels.Length; m++)
            {
                simple._leveldata[m] = CheckBrickColorTable(AllPixels[m]);
            }

            var output = JsonUtility.ToJson(simple, true);
            if (output == String.Empty) return;
            Debug.Log(output);

        }

        /// <summary>
        /// Convierte del color del pixel al tipo de Brick para el juego, definido en el Excel...
        /// </summary>
        /// <param name="col"></param>
        /// <returns></returns>
        private static int CheckBrickColorTable(Color32 col)
        {
            int temp = 0;

            Color32 brick_empty = new Color32(0, 0, 0, 0);
            Color32 brick_clear = new Color32(255, 255, 255, 0);
            Color32 brick_white = new Color32(255, 255, 255, 255);
            Color32 brick_grey = new Color32(127, 127, 127, 255);
            Color32 brick_gray = new Color32(128, 128, 128, 255);
            Color32 brick_yellow = new Color32(255, 255, 0, 255);
            Color32 brick_red = new Color32(255, 0, 0, 255);
            Color32 brick_black = new Color32(0, 0, 0, 255);

            //cada color de brick
            if (col.r == brick_empty.r && col.g == brick_empty.g && col.b == brick_empty.b &&
                col.a == brick_empty.a) return 0;
            if (col.r == brick_clear.r && col.g == brick_clear.g && col.b == brick_clear.b &&
                col.a == brick_clear.a) return 0;
            if (col.r == brick_white.r && col.g == brick_white.g && col.b == brick_white.b &&
                col.a == brick_white.a) return 1;
            if (col.r == brick_grey.r && col.g == brick_grey.g && col.b == brick_grey.b &&
                col.a == brick_grey.a) return 1;
            if (col.r == brick_gray.r && col.g == brick_gray.g && col.b == brick_gray.b &&
                col.a == brick_gray.a) return 1;
            if (col.r == brick_yellow.r && col.g == brick_yellow.g && col.b == brick_yellow.b &&
                col.a == brick_yellow.a) return 2;
            if (col.r == brick_red.r && col.g == brick_red.g && col.b == brick_red.b && 
                col.a == brick_red.a) return 4;
            if (col.r == brick_black.r && col.g == brick_black.g && col.b == brick_black.b &&
                col.a == brick_black.a) return 9;

            return temp;
        }
    }
}



