﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace mierdergames.sdk
{
    public class generador_InteraccionesBrick : MonoBehaviour
    {
        
        
        [MenuItem("MierderGames/Heronoid/SDK/Skills/Generar Asset de Interaccion Skill vs Bricks...")]
        static void GeneraAssetInteraccionesBrick()
        {
            string path = EditorUtility.SaveFilePanelInProject("Save asset as...", "Interaction_XXX", "asset", "asset file");
            if (string.IsNullOrEmpty(path)) return;
            
            var so = ScriptableObject.CreateInstance<SO_InteraccionBrick>();
            
            //aquí va todo el serializador de datos...
            so.interacciones = new List<InteractionBrick>();
            for (int i = 0; i < 10; i++)
            {
                so.interacciones.Add(new InteractionBrick(i));
            }
            so.interacciones.Add(new InteractionBrick(13));
            so.interacciones.Add(new InteractionBrick(15));
            so.interacciones.Add(new InteractionBrick(19));
            so.interacciones.Add(new InteractionBrick(20));
            so.interacciones.Add(new InteractionBrick(21));
            so.interacciones.Add(new InteractionBrick(22));
            //

            AssetDatabase.CreateAsset(so, path);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }
        
    }
}