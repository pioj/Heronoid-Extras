﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//IMPORTANTE: class DUMMY de un Brick, SOLO USAR EN EL SDK para generar ficheros. NO SUSTITUIR POR EL DEL JUEGO. 

public class brick : MonoBehaviour
{
    [SerializeField] private int idBrick;
    public int IdBrick => idBrick;
}
