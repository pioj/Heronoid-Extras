﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEditor;
using UnityEngine;

namespace mierdergames.tools
{
   public class Editor_GenerateTheme : ScriptableWizard
   {
      [Tooltip("Image with the Theme")] public Texture2D imageTheme;

      [Tooltip("Palette asset used by the Theme")] public SO_PaletaTheme paletteAsset;

      [MenuItem("MierderGames/Heronoid/SDK/Themes/Generate Theme from Image...")]
      private static void CreateWizard()
      {
         ScriptableWizard.DisplayWizard<Editor_GenerateTheme>("Generate Theme from Image", "Generate");
      }

      private void OnWizardCreate()
      {
         if ( imageTheme== null || paletteAsset == null || paletteAsset.theme.Count < 1) return;

         GenTheme(imageTheme, paletteAsset);
         
         Debug.Log("Theme created successfully.");
      }
      
      private void OnWizardUpdate()
      {
         helpString = "Please select a valid file!";
      }

      // When the user presses the "Apply" button OnWizardOtherButton is called.
      void OnWizardOtherButton() { }

      private void GenTheme(Texture2D tex2d, SO_PaletaTheme theme)
      {
         var tempix = tex2d.GetPixels(0, 0, tex2d.width, tex2d.height);
         Color32[] pixels = new Color32[tempix.Length];
           
         //saco pixeles
         for (int i = 0; i < tempix.Length; i++)
         {
            pixels[i].r = (byte)(tempix[i].r * 255);
            pixels[i].g = (byte)(tempix[i].g * 255);
            pixels[i].b = (byte)(tempix[i].b * 255);
            pixels[i].a = (byte)(tempix[i].a * 255);
         }
         
         var Go = new GameObject("THEME");
         
         for (int x = 0; x < tex2d.width; x++)
         {
            for (int y = 0; y < tex2d.height; y++)
            {
               var colors = theme.GetColors();

               //comparo cada color de la paleta con los pixeles de la textura pasada
               for (int w = 0; w < colors.Length; w++)
               {
                  if (colors[w].Equals( pixels[(y * tex2d.width) + x] ))
                  {
                     var tilecito = Instantiate(theme.theme[w]._prefabTile);
                     tilecito.transform.name = "Tilecito";
                     tilecito.transform.position = new Vector3(x,y,0);
                     tilecito.transform.SetParent(Go.transform);
                     
                  }
               }

            }
         }
      }
      
   }
   
}
